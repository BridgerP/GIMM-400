﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReturnToPlayer : dragState
{
    public ReturnToPlayer(Dragon dragon) : base(dragon) { }
    public override void OnEnter()
    {
        dragon.toyTime = false;
        //Debug.Log("Returning to Player");
    }
    public override void OnUpdate()
    {
        dragon.agent.SetDestination(dragon.player.transform.position);
        if(Vector3.Distance(dragon.transform.position, dragon.player.transform.position) < 10)
        {
            dragon.toy.GetComponent<grabbable>().unGrab(5, Vector3.forward);

            dragon.changeState(new FollowPlayer(dragon));
        }
    }
    public override void OnExit()
    {
        dragon.toy = null;
        //Debug.Log("Dropped Toy");
    }
}
